import { Question } from '../types';

export const questions: Question[] = [
  {
    id: 1,
    text: "¿Qué número debería seguir en esta serie: 2, 4, 8, 16, ...?",
    options: [
      { id: 1, text: "24" },
      { id: 2, text: "32" },
      { id: 3, text: "30" },
      { id: 4, text: "20" }
    ],
    correctOptionId: 2
  },
  {
    id: 2,
    text: "¿Cuál de estas formas es diferente de las otras?",
    options: [
      { id: 1, text: "Cuadrado" },
      { id: 2, text: "Rectángulo" },
      { id: 3, text: "Triángulo" },
      { id: 4, text: "Rombo" }
    ],
    correctOptionId: 3
  },
  {
    id: 3,
    text: "Si un avión se estrella en la frontera entre Estados Unidos y México, ¿dónde entierran a los supervivientes?",
    options: [
      { id: 1, text: "Estados Unidos" },
      { id: 2, text: "México" },
      { id: 3, text: "Ambos países" },
      { id: 4, text: "Los supervivientes no se entierran" }
    ],
    correctOptionId: 4
  },
  {
    id: 4,
    text: "Si una casa roja está hecha de ladrillos rojos, y una casa azul está hecha de ladrillos azules, ¿de qué está hecha una casa verde?",
    options: [
      { id: 1, text: "Ladrillos verdes" },
      { id: 2, text: "Plantas" },
      { id: 3, text: "Vidrio" },
      { id: 4, text: "Madera pintada de verde" }
    ],
    correctOptionId: 3
  },
  {
    id: 5,
    text: "Completa la analogía: Mano es a Guante como Cabeza es a...",
    options: [
      { id: 1, text: "Sombrero" },
      { id: 2, text: "Cerebro" },
      { id: 3, text: "Cabello" },
      { id: 4, text: "Cuello" }
    ],
    correctOptionId: 1
  },
  {
    id: 6,
    text: "¿Cuál es el número que falta en esta secuencia: 1, 4, 9, 16, 25, 36, __, 64?",
    options: [
      { id: 1, text: "49" },
      { id: 2, text: "42" },
      { id: 3, text: "47" },
      { id: 4, text: "51" }
    ],
    correctOptionId: 1
  },
  {
    id: 7,
    text: "¿Qué palabra NO pertenece al grupo?",
    options: [
      { id: 1, text: "Manzana" },
      { id: 2, text: "Plátano" },
      { id: 3, text: "Zanahoria" },
      { id: 4, text: "Naranja" }
    ],
    correctOptionId: 3
  },
  {
    id: 8,
    text: "¿Qué sigue en este patrón: O, T, T, F, F, S, S, ?",
    options: [
      { id: 1, text: "E" },
      { id: 2, text: "N" },
      { id: 3, text: "S" },
      { id: 4, text: "T" }
    ],
    correctOptionId: 2
  },
  {
    id: 9,
    text: "Si reordenas las letras 'ATOCE', tendrías el nombre de:",
    options: [
      { id: 1, text: "Una ciudad" },
      { id: 2, text: "Un animal" },
      { id: 3, text: "Una fruta" },
      { id: 4, text: "Un país" }
    ],
    correctOptionId: 3
  },
  {
    id: 10,
    text: "Si hoy es lunes, ¿qué día será dentro de 180 días?",
    options: [
      { id: 1, text: "Domingo" },
      { id: 2, text: "Lunes" },
      { id: 3, text: "Martes" },
      { id: 4, text: "Miércoles" }
    ],
    correctOptionId: 1
  }
];