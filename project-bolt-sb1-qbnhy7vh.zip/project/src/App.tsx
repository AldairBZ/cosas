import React from 'react';
import { AnimatePresence } from 'framer-motion';
import Layout from './components/Layout';
import WelcomeScreen from './components/WelcomeScreen';
import QuestionScreen from './components/QuestionScreen';
import ResultsScreen from './components/ResultsScreen';
import { useAppStore } from './store/useAppStore';

function App() {
  const appState = useAppStore(state => state.appState);
  
  return (
    <Layout>
      <AnimatePresence mode="wait">
        {appState === 'welcome' && <WelcomeScreen key="welcome" />}
        {appState === 'question' && <QuestionScreen key="question" />}
        {appState === 'results' && <ResultsScreen key="results" />}
      </AnimatePresence>
    </Layout>
  );
}

export default App;