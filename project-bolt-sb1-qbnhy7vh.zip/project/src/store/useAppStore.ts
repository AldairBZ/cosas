import { create } from 'zustand';
import { questions } from '../data/questions';
import { AppState } from '../types';
import { calculateIQ } from '../utils/calculateIQ';

interface Answer {
  questionId: number;
  selectedOptionId: number;
}

interface AppStore {
  // Estado de la aplicación
  appState: AppState;
  currentQuestionIndex: number;
  answers: Answer[];
  score: number;
  iq: number | null;
  
  // Acciones
  startTest: () => void;
  answerQuestion: (questionId: number, selectedOptionId: number) => void;
  goToNextQuestion: () => void;
  goToPreviousQuestion: () => void;
  calculateResults: () => void;
  restartTest: () => void;
  
  // Getters
  getCurrentQuestion: () => typeof questions[0] | undefined;
  isLastQuestion: () => boolean;
  getSelectedOptionForCurrentQuestion: () => number | undefined;
  getProgress: () => number;
}

export const useAppStore = create<AppStore>((set, get) => ({
  // Estado inicial
  appState: 'welcome',
  currentQuestionIndex: 0,
  answers: [],
  score: 0,
  iq: null,
  
  // Acciones
  startTest: () => set({ 
    appState: 'question',
    currentQuestionIndex: 0,
    answers: [],
    score: 0,
    iq: null
  }),
  
  answerQuestion: (questionId, selectedOptionId) => set((state) => {
    // Verificar si ya existe una respuesta para esta pregunta
    const existingAnswerIndex = state.answers.findIndex(a => a.questionId === questionId);
    
    // Crear nuevo array de respuestas
    const newAnswers = [...state.answers];
    
    if (existingAnswerIndex !== -1) {
      // Actualizar respuesta existente
      newAnswers[existingAnswerIndex] = { questionId, selectedOptionId };
    } else {
      // Agregar nueva respuesta
      newAnswers.push({ questionId, selectedOptionId });
    }
    
    return { answers: newAnswers };
  }),
  
  goToNextQuestion: () => set((state) => {
    if (state.currentQuestionIndex < questions.length - 1) {
      return { currentQuestionIndex: state.currentQuestionIndex + 1 };
    }
    return state;
  }),
  
  goToPreviousQuestion: () => set((state) => {
    if (state.currentQuestionIndex > 0) {
      return { currentQuestionIndex: state.currentQuestionIndex - 1 };
    }
    return state;
  }),
  
  calculateResults: () => set((state) => {
    // Calcular puntuación
    const correctAnswers = state.answers.filter(answer => {
      const question = questions.find(q => q.id === answer.questionId);
      return question?.correctOptionId === answer.selectedOptionId;
    });
    
    const score = correctAnswers.length;
    const iq = calculateIQ(score);
    
    return {
      appState: 'results',
      score,
      iq
    };
  }),
  
  restartTest: () => set({
    appState: 'welcome',
    currentQuestionIndex: 0,
    answers: [],
    score: 0,
    iq: null
  }),
  
  // Getters
  getCurrentQuestion: () => {
    const { currentQuestionIndex } = get();
    return questions[currentQuestionIndex];
  },
  
  isLastQuestion: () => {
    const { currentQuestionIndex } = get();
    return currentQuestionIndex === questions.length - 1;
  },
  
  getSelectedOptionForCurrentQuestion: () => {
    const { currentQuestionIndex, answers } = get();
    const currentQuestion = questions[currentQuestionIndex];
    const answer = answers.find(a => a.questionId === currentQuestion.id);
    return answer?.selectedOptionId;
  },
  
  getProgress: () => {
    const { currentQuestionIndex } = get();
    return ((currentQuestionIndex + 1) / questions.length) * 100;
  }
}));