import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps {
  children: React.ReactNode;
  onClick: () => void;
  primary?: boolean;
  secondary?: boolean;
  fullWidth?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({
  children,
  onClick,
  primary = false,
  secondary = false,
  fullWidth = false,
  disabled = false,
  icon,
  className = '',
}) => {
  // Definir las clases base
  let buttonClasses = 'px-6 py-3 rounded-lg font-medium transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 ';
  
  // Agregar clases según el tipo de botón
  if (primary) {
    buttonClasses += 'bg-purple-500 hover:bg-purple-600 text-white focus:ring-purple-400 ';
  } else if (secondary) {
    buttonClasses += 'bg-teal-500 hover:bg-teal-600 text-white focus:ring-teal-400 ';
  } else {
    buttonClasses += 'bg-gray-100 hover:bg-gray-200 text-gray-800 focus:ring-gray-300 ';
  }
  
  // Agregar clases adicionales
  if (fullWidth) {
    buttonClasses += 'w-full ';
  }
  
  if (disabled) {
    buttonClasses += 'opacity-50 cursor-not-allowed ';
  }
  
  // Agregar clases personalizadas
  buttonClasses += className;
  
  return (
    <motion.button
      whileHover={{ scale: disabled ? 1 : 1.03 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      className={buttonClasses}
      onClick={onClick}
      disabled={disabled}
      transition={{ type: 'spring', stiffness: 400, damping: 17 }}
    >
      <div className="flex items-center justify-center">
        {icon && <span className="mr-2">{icon}</span>}
        {children}
      </div>
    </motion.button>
  );
};

export default Button;