import React from 'react';
import { motion } from 'framer-motion';

interface OptionButtonProps {
  id: number;
  text: string;
  selected: boolean;
  onClick: (id: number) => void;
}

const OptionButton: React.FC<OptionButtonProps> = ({ id, text, selected, onClick }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        type: 'spring',
        stiffness: 300,
        damping: 20,
        delay: id * 0.1, // Agrega un retraso escalonado basado en el ID
      }}
      className="w-full"
    >
      <button
        className={`w-full text-left p-4 rounded-lg border-2 transition-all mb-3
          ${selected
            ? 'border-purple-500 bg-purple-50 text-purple-700'
            : 'border-gray-200 hover:border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
          }`}
        onClick={() => onClick(id)}
      >
        <div className="flex items-center">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full mr-3 
            ${selected ? 'bg-purple-500 text-white' : 'bg-gray-100 text-gray-700'}`}
          >
            {String.fromCharCode(64 + id)}
          </div>
          <span className="text-lg">{text}</span>
        </div>
      </button>
    </motion.div>
  );
};

export default OptionButton;