import React from 'react';
import { motion } from 'framer-motion';
import { Brain } from 'lucide-react';
import Button from './common/Button';
import { useAppStore } from '../store/useAppStore';

const WelcomeScreen: React.FC = () => {
  const startTest = useAppStore(state => state.startTest);
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-3xl mx-auto p-6 md:p-8"
    >
      <motion.div 
        className="text-center mb-8"
        initial={{ y: -20 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-center mb-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ 
              type: "spring",
              stiffness: 260,
              damping: 20,
              delay: 0.2
            }}
            className="p-3 bg-purple-100 text-purple-600 rounded-full"
          >
            <Brain size={48} />
          </motion.div>
        </div>
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-3xl md:text-4xl font-bold text-gray-800 mb-2"
        >
          Test de Coeficiente Intelectual
        </motion.h1>
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-lg text-gray-600 mb-6"
        >
          Descubre tu nivel de IQ con nuestro test rápido
        </motion.p>
      </motion.div>
      
      <motion.div 
        className="bg-white rounded-xl shadow-lg p-6 md:p-8 mb-8"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Instrucciones</h2>
        <ul className="space-y-3 text-gray-700 mb-6">
          <li className="flex items-start">
            <span className="inline-flex items-center justify-center w-6 h-6 bg-purple-100 text-purple-600 rounded-full mr-3 flex-shrink-0">1</span>
            <span>El test consta de 10 preguntas de opción múltiple.</span>
          </li>
          <li className="flex items-start">
            <span className="inline-flex items-center justify-center w-6 h-6 bg-purple-100 text-purple-600 rounded-full mr-3 flex-shrink-0">2</span>
            <span>Cada pregunta tiene una única respuesta correcta.</span>
          </li>
          <li className="flex items-start">
            <span className="inline-flex items-center justify-center w-6 h-6 bg-purple-100 text-purple-600 rounded-full mr-3 flex-shrink-0">3</span>
            <span>No hay límite de tiempo, pero intenta responder sin consultar ayuda externa.</span>
          </li>
          <li className="flex items-start">
            <span className="inline-flex items-center justify-center w-6 h-6 bg-purple-100 text-purple-600 rounded-full mr-3 flex-shrink-0">4</span>
            <span>Al finalizar, recibirás una estimación de tu IQ basada en tus respuestas.</span>
          </li>
        </ul>
        
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                Este test es solo una estimación y no debe considerarse como un indicador preciso de tu inteligencia real.
              </p>
            </div>
          </div>
        </div>
      </motion.div>
      
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.7 }}
        className="text-center"
      >
        <Button 
          primary 
          onClick={startTest}
          className="text-lg px-10 py-4"
        >
          Comenzar Test
        </Button>
      </motion.div>
    </motion.div>
  );
};

export default WelcomeScreen;