import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Award, BarChart, RefreshCw } from 'lucide-react';
import Button from './common/Button';
import { useAppStore } from '../store/useAppStore';
import { getIQInterpretation } from '../utils/calculateIQ';

const ResultsScreen: React.FC = () => {
  const { score, iq, restartTest } = useAppStore();
  const [showScore, setShowScore] = React.useState(false);
  const [showIQ, setShowIQ] = React.useState(false);
  const [showInterpretation, setShowInterpretation] = React.useState(false);
  
  const interpretation = iq ? getIQInterpretation(iq) : { category: '', description: '' };
  
  // Efectos para animar la aparición de resultados
  useEffect(() => {
    const timer1 = setTimeout(() => setShowScore(true), 500);
    const timer2 = setTimeout(() => setShowIQ(true), 1500);
    const timer3 = setTimeout(() => setShowInterpretation(true), 2500);
    
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, []);
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-3xl mx-auto p-6 md:p-8"
    >
      <motion.div 
        className="text-center mb-8"
        initial={{ y: -20 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ 
            type: "spring", 
            stiffness: 260, 
            damping: 20 
          }}
          className="mx-auto mb-6"
        >
          <div className="flex justify-center">
            <div className="p-3 bg-purple-100 text-purple-600 rounded-full">
              <Award size={48} />
            </div>
          </div>
        </motion.div>
        
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-3xl md:text-4xl font-bold text-gray-800 mb-2"
        >
          Resultados del Test
        </motion.h1>
        
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-lg text-gray-600"
        >
          Aquí está tu puntuación y coeficiente intelectual estimado
        </motion.p>
      </motion.div>
      
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <motion.div 
          className="bg-white rounded-xl shadow-lg p-6 md:p-8 text-center"
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-yellow-100 text-yellow-600 rounded-full">
              <BarChart size={32} />
            </div>
          </div>
          
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Puntuación</h3>
          
          {showScore ? (
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <p className="text-5xl font-bold text-gray-900 mb-2">{score} / 10</p>
              <p className="text-gray-600">Respuestas correctas</p>
            </motion.div>
          ) : (
            <div className="h-24 flex items-center justify-center">
              <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}
        </motion.div>
        
        <motion.div 
          className="bg-white rounded-xl shadow-lg p-6 md:p-8 text-center"
          initial={{ x: 50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-purple-100 text-purple-600 rounded-full">
              <Award size={32} />
            </div>
          </div>
          
          <h3 className="text-lg font-semibold text-gray-700 mb-2">IQ Estimado</h3>
          
          {showIQ ? (
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <p className="text-5xl font-bold text-gray-900 mb-2">{iq}</p>
              <p className="text-gray-600">Nivel de {interpretation.category}</p>
            </motion.div>
          ) : (
            <div className="h-24 flex items-center justify-center">
              <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}
        </motion.div>
      </div>
      
      {showInterpretation && (
        <motion.div 
          className="bg-white rounded-xl shadow-lg p-6 md:p-8 mb-8"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Interpretación</h3>
          <p className="text-gray-700 mb-4">{interpretation.description}</p>
          
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-r-lg">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-blue-700">
                  Recuerda que este test es solo una estimación. La inteligencia es multifacética y un test corto no puede medir todas sus dimensiones.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      )}
      
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="text-center"
      >
        <Button 
          onClick={restartTest}
          icon={<RefreshCw size={20} />}
          className="text-lg px-10 py-3"
        >
          Reiniciar Test
        </Button>
      </motion.div>
    </motion.div>
  );
};

export default ResultsScreen;