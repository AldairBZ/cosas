import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import Button from './common/Button';
import OptionButton from './common/OptionButton';
import ProgressBar from './ProgressBar';
import { useAppStore } from '../store/useAppStore';

const QuestionScreen: React.FC = () => {
  const { 
    getCurrentQuestion, 
    getSelectedOptionForCurrentQuestion,
    getProgress,
    answerQuestion,
    goToNextQuestion,
    goToPreviousQuestion,
    calculateResults,
    isLastQuestion,
    currentQuestionIndex
  } = useAppStore();
  
  const currentQuestion = getCurrentQuestion();
  const selectedOptionId = getSelectedOptionForCurrentQuestion();
  const progress = getProgress();
  
  const handleOptionSelect = (optionId: number) => {
    if (currentQuestion) {
      answerQuestion(currentQuestion.id, optionId);
    }
  };
  
  const handleNextClick = () => {
    if (isLastQuestion()) {
      calculateResults();
    } else {
      goToNextQuestion();
    }
  };
  
  if (!currentQuestion) return null;
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-3xl mx-auto p-6 md:p-8"
    >
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <span className="text-sm font-medium text-gray-500">
            Pregunta {currentQuestionIndex + 1} de 10
          </span>
          <span className="text-sm font-medium text-purple-600">
            {Math.round(progress)}% Completado
          </span>
        </div>
        <ProgressBar progress={progress} />
      </div>
      
      <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 mb-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion.id}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            <h2 className="text-xl md:text-2xl font-semibold text-gray-800 mb-6">
              {currentQuestion.text}
            </h2>
            
            <div className="space-y-3 mb-8">
              {currentQuestion.options.map((option) => (
                <OptionButton
                  key={option.id}
                  id={option.id}
                  text={option.text}
                  selected={selectedOptionId === option.id}
                  onClick={handleOptionSelect}
                />
              ))}
            </div>
          </motion.div>
        </AnimatePresence>
        
        <div className="flex justify-between mt-8">
          <Button 
            onClick={goToPreviousQuestion} 
            disabled={currentQuestionIndex === 0}
            icon={<ChevronLeft size={20} />}
          >
            Anterior
          </Button>
          
          <Button 
            primary 
            onClick={handleNextClick}
            disabled={selectedOptionId === undefined}
            icon={<ChevronRight size={20} className="ml-2" />}
            className={isLastQuestion() ? 'bg-teal-500 hover:bg-teal-600' : ''}
          >
            {isLastQuestion() ? 'Ver resultados' : 'Siguiente'}
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default QuestionScreen;