/**
 * Calcula el IQ estimado basado en la puntuación obtenida
 * La escala es aproximada: 10 preguntas correctas = 130 IQ
 * @param score Número de respuestas correctas (0-10)
 * @returns IQ estimado
 */
export const calculateIQ = (score: number): number => {
  // Base IQ of 70 + 6 points per correct answer
  const baseIQ = 70;
  const pointsPerCorrectAnswer = 6;
  
  // Calculate estimated IQ with a slight randomization factor
  // This makes the results feel more authentic with small variations
  const estimatedIQ = baseIQ + (score * pointsPerCorrectAnswer);
  
  // Add a small random factor (±3 points) to make it less predictable
  const randomFactor = Math.floor(Math.random() * 7) - 3;
  
  return Math.max(70, Math.min(145, estimatedIQ + randomFactor));
};

/**
 * Obtiene la interpretación del IQ basado en el puntaje
 * @param iq Puntaje de IQ
 * @returns Objeto con categoría y descripción
 */
export const getIQInterpretation = (iq: number): { category: string; description: string } => {
  if (iq < 80) {
    return {
      category: "Por debajo del promedio",
      description: "Tienes algunas áreas que podrías mejorar con práctica adicional."
    };
  } else if (iq < 90) {
    return {
      category: "Promedio bajo",
      description: "Tu puntuación está dentro del rango normal, pero en el lado inferior."
    };
  } else if (iq < 110) {
    return {
      category: "Promedio",
      description: "Tu puntuación está dentro del rango promedio de la población."
    };
  } else if (iq < 120) {
    return {
      category: "Promedio alto",
      description: "Tu puntuación está por encima del promedio de la población."
    };
  } else if (iq < 130) {
    return {
      category: "Superior",
      description: "Has demostrado una capacidad de razonamiento superior al promedio."
    };
  } else {
    return {
      category: "Muy superior",
      description: "Tu puntuación sugiere una capacidad de razonamiento excepcional."
    };
  }
};